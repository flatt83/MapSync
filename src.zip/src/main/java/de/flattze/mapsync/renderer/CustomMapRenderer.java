package de.flattze.mapsync.renderer;

import org.bukkit.entity.Player;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;

public class CustomMapRenderer extends MapRenderer {

    private final byte[] colors;
    private boolean rendered = false;

    public CustomMapRenderer(byte[] colors) {
        super(true); // true = nur einmal rendern

        if (colors == null) {
            throw new IllegalArgumentException("Map colors cannot be null!");
        }
        if (colors.length != 128 * 128) {
            throw new IllegalArgumentException("Map colors length must be 16384 bytes but got: " + colors.length);
        }

        this.colors = colors;
    }

    @Override
    public void render(MapView view, MapCanvas canvas, Player player) {
        if (rendered) return; // nur einmal rendern

        for (int y = 0; y < 128; y++) {
            for (int x = 0; x < 128; x++) {
                int index = y * 128 + x;
                byte color = colors[index];
                canvas.setPixel(x, y, color);
            }
        }
        rendered = true;
    }
}
