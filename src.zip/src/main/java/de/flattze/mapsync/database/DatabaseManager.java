package de.flattze.mapsync.database;

import com.flowpowered.nbt.ByteArrayTag;
import com.flowpowered.nbt.CompoundTag;
import com.flowpowered.nbt.Tag;
import com.flowpowered.nbt.stream.NBTInputStream;
import de.flattze.mapsync.MapSyncPlugin;
import de.flattze.mapsync.data.MapRecord;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.GZIPInputStream;

public class DatabaseManager {

    private final MapSyncPlugin plugin;
    private Connection connection;

    public DatabaseManager(MapSyncPlugin plugin) {
        this.plugin = plugin;
    }

    public void connect() {
        try {
            String url = "jdbc:mysql://" + plugin.getConfig().getString("database.host")
                    + ":" + plugin.getConfig().getInt("database.port")
                    + "/" + plugin.getConfig().getString("database.database");

            String user = plugin.getConfig().getString("database.username");
            String pass = plugin.getConfig().getString("database.password");

            this.connection = DriverManager.getConnection(url, user, pass);
            plugin.getLogger().info("[MapSync] Datenbank-Verbindung erfolgreich.");

            checkAndCreateTable();
        } catch (SQLException e) {
            plugin.getLogger().severe("[MapSync] DB-Verbindung fehlgeschlagen: " + e.getMessage());
        }
    }


    // ✅ Holt eine Map — KEIN Entpacken mehr
    public MapRecord getMapById(int mapId) {
        try {
            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM maps WHERE map_id = ?"
            );
            stmt.setInt(1, mapId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                byte[] rawData = rs.getBytes("map_data");

                if (rawData == null || rawData.length != 128 * 128) {
                    plugin.getLogger().severe("[MapSync] Fehler: MapData für ID " + mapId +
                            " hat ungültige Länge: " + (rawData != null ? rawData.length : "null"));
                    return null;
                }

                plugin.getLogger().info("[MapSync] Geladene Rohdaten, Länge: " + rawData.length);

                return new MapRecord(
                        rs.getInt("map_id"),
                        rs.getString("owner_name"),
                        rawData
                );
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Fehler beim Laden der Karte: " + e.getMessage());
        }
        return null;
    }

    // ✅ Führt Migrationslauf durch — wandelt .dat-Files in RawBytes
    public void migrateMaps(File mapFolder) {
        File[] files = mapFolder.listFiles((dir, name) -> name.startsWith("map_") && name.endsWith(".dat"));
        if (files == null) {
            plugin.getLogger().severe("[MapSync] Keine Karten-Dateien gefunden.");
            return;
        }

        for (File file : files) {
            try {
                int mapId = Integer.parseInt(file.getName().substring(4, file.getName().length() - 4));
                byte[] colors = readColorsFromDat(file);

                if (colors == null || colors.length != 128 * 128) {
                    plugin.getLogger().severe("[MapSync] Fehler beim Lesen von " + file.getName() +
                            ": Datenlänge ist ungültig: " + (colors != null ? colors.length : "null"));
                    continue;
                }

                storeRawMap(mapId, colors, "migrated-owner");

                plugin.getLogger().info("[MapSync] Migriert: " + file.getName() + " -> Länge: " + colors.length);

            } catch (Exception e) {
                plugin.getLogger().severe("[MapSync] Fehler beim Migrating " + file.getName() + ": " + e.getMessage());
            }
        }
    }

    // ✅ Speichert RAW ins DB — keine Kompression mehr!
    public void storeRawMap(int mapId, byte[] colors, String owner) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO maps (map_id, owner_name, map_data) VALUES (?, ?, ?) " +
                        "ON DUPLICATE KEY UPDATE map_data = ?"
        );
        stmt.setInt(1, mapId);
        stmt.setString(2, owner);
        stmt.setBytes(3, colors);
        stmt.setBytes(4, colors);
        stmt.executeUpdate();
    }

    // ✅ Liest Farben aus Vanilla .dat-Dateien
    public byte[] readColorsFromDat(File file) {
        try (FileInputStream fis = new FileInputStream(file);
             GZIPInputStream gis = new GZIPInputStream(fis);
             NBTInputStream nbtIn = new NBTInputStream(gis)) {

            CompoundTag root = (CompoundTag) nbtIn.readTag();
            CompoundTag data = (CompoundTag) root.getValue().get("data");

            Tag<?> colorsTag = data.getValue().get("colors");

            if (!(colorsTag instanceof ByteArrayTag byteArrayTag)) {
                plugin.getLogger().severe("[MapSync] " + file.getName() + " hat kein gültiges ByteArrayTag für Farben!");
                return null;
            }

            byte[] colors = byteArrayTag.getValue();

            if (colors.length != 128 * 128) {
                plugin.getLogger().severe("[MapSync] " + file.getName() + " hat nur " + colors.length + " statt 16384 Bytes!");
                return null;
            }

            return colors;

        } catch (Exception e) {
            plugin.getLogger().severe("[MapSync] Fehler beim Lesen " + file.getName() + ": " + e.getMessage());
            return null;
        }
    }


    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void uploadMap(int mapId, UUID ownerId, String ownerName, byte[] colors) {
        try {
            if (colors.length != 16384) {
                throw new IllegalArgumentException("uploadMap: Farben müssen 16384 Bytes sein!");
            }

            PreparedStatement stmt = connection.prepareStatement(
                    "INSERT INTO maps (map_id, owner_name, map_data) VALUES (?, ?, ?) " +
                            "ON DUPLICATE KEY UPDATE map_data = ?"
            );
            stmt.setInt(1, mapId);
            stmt.setString(2, ownerId.toString());
            stmt.setBytes(3, colors);
            stmt.setBytes(4, colors);

            stmt.executeUpdate();

            plugin.getLogger().info("[MapSync] Karte " + mapId + " hochgeladen.");
        } catch (SQLException e) {
            plugin.getLogger().severe("[MapSync] Fehler bei uploadMap: " + e.getMessage());
        }
    }

    public List<MapRecord> getMapsFor(UUID ownerId) {
        List<MapRecord> maps = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(
                    "SELECT * FROM maps WHERE owner_name = ?"
            );
            stmt.setString(1, ownerId.toString());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                byte[] data = rs.getBytes("map_data");
                if (data != null && data.length == 16384) {
                    maps.add(new MapRecord(
                            rs.getInt("map_id"),
                            rs.getString("owner_name"),
                            data
                    ));
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("[MapSync] Fehler bei getMapsFor: " + e.getMessage());
        }
        return maps;
    }

    public void checkAndCreateTable() {
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate("""
            CREATE TABLE IF NOT EXISTS maps (
                map_id INT PRIMARY KEY,
                owner_name VARCHAR(100) NOT NULL,
                map_data BLOB NOT NULL
            )
        """);
            plugin.getLogger().info("[MapSync] Tabelle 'maps' geprüft oder neu erstellt.");
        } catch (SQLException e) {
            plugin.getLogger().severe("[MapSync] Fehler beim Erstellen/Prüfen der Tabelle: " + e.getMessage());
        }
    }


}
