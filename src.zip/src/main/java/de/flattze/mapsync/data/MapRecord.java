package de.flattze.mapsync.data;

public record MapRecord(int mapId, String ownerName, byte[] mapData) {}

